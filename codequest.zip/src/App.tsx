import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import ChallengeList from './components/ChallengeList';
import ChallengeDetail from './components/ChallengeDetail';
import AdminDashboard from './components/AdminDashboard';
import AdminChallengeForm from './components/AdminChallengeForm';
import Profile from './components/Profile';
import { Toaster } from 'sonner';
import { ThemeProvider } from './context/ThemeContext';

export default function App() {
  return (
    <ThemeProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex flex-col font-sans transition-colors duration-300">
          <Navbar />
          <main className="flex-grow">
            <Routes>
              <Route path="/" element={<ChallengeList />} />
              <Route path="/challenge/:id" element={<ChallengeDetail />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/new" element={<AdminChallengeForm />} />
              <Route path="/admin/edit/:id" element={<AdminChallengeForm />} />
            </Routes>
          </main>
          <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 py-8 transition-colors duration-300">
            <div className="max-w-7xl mx-auto px-4 text-center text-gray-500 dark:text-gray-400 text-sm">
              &copy; {new Date().getFullYear()} CodeQuest. Built for developers.
            </div>
          </footer>
          <Toaster position="top-center" richColors />
        </div>
      </Router>
    </ThemeProvider>
  );
}
