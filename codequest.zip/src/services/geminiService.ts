import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

export interface ExecutionResult {
  passed: boolean;
  actualOutput: string;
  error?: string;
}

export async function executeCode(
  code: string,
  language: string,
  input: string,
  expectedOutput: string
): Promise<ExecutionResult> {
  const prompt = `
    You are a code execution engine. Execute the following code in ${language} with the provided input.
    Compare the output with the expected output.
    
    CODE:
    ${code}
    
    INPUT:
    ${input}
    
    EXPECTED OUTPUT:
    ${expectedOutput}
    
    Return the result in JSON format.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            passed: { type: Type.BOOLEAN },
            actualOutput: { type: Type.STRING },
            error: { type: Type.STRING, description: "Any runtime or compilation errors" }
          },
          required: ["passed", "actualOutput"]
        }
      }
    });

    const result = JSON.parse(response.text || "{}");
    return {
      passed: result.passed ?? false,
      actualOutput: result.actualOutput ?? "",
      error: result.error
    };
  } catch (error) {
    console.error("Gemini execution error:", error);
    return {
      passed: false,
      actualOutput: "",
      error: "Failed to execute code via AI engine."
    };
  }
}
