import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db, doc, getDoc, collection, getDocs, addDoc, updateDoc, deleteDoc, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { Challenge, TestCase } from '../types';
import { toast } from 'sonner';
import { Save, ArrowLeft, Plus, Trash2, Loader2, Code2, Terminal, Info, Eye, EyeOff } from 'lucide-react';
import { cn } from '../lib/utils';

export default function AdminChallengeForm() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(id ? true : false);
  const [saving, setSaving] = useState(false);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Easy');
  const [tags, setTags] = useState('');
  const [testCases, setTestCases] = useState<Partial<TestCase>[]>([
    { input: '', expectedOutput: '', isHidden: false }
  ]);

  useEffect(() => {
    if (!id) return;

    const fetchData = async () => {
      const path = `challenges/${id}`;
      try {
        const challengeDoc = await getDoc(doc(db, 'challenges', id));
        if (challengeDoc.exists()) {
          const data = challengeDoc.data() as Challenge;
          setTitle(data.title);
          setDescription(data.description);
          setDifficulty(data.difficulty);
          setTags(data.tags?.join(', ') || '');

          const testCasesSnap = await getDocs(collection(db, 'challenges', id, 'testCases'));
          setTestCases(testCasesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as TestCase)));
        } else {
          toast.error('Challenge not found');
          navigate('/admin');
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, path);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, navigate]);

  const handleAddTestCase = () => {
    setTestCases([...testCases, { input: '', expectedOutput: '', isHidden: false }]);
  };

  const handleRemoveTestCase = (index: number) => {
    setTestCases(testCases.filter((_, i) => i !== index));
  };

  const handleTestCaseChange = (index: number, field: keyof TestCase, value: any) => {
    const newTestCases = [...testCases];
    newTestCases[index] = { ...newTestCases[index], [field]: value };
    setTestCases(newTestCases);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;

    if (!title || !description || testCases.some(tc => !tc.expectedOutput)) {
      toast.error('Please fill in all required fields and test cases.');
      return;
    }

    setSaving(true);
    try {
      const challengeData = {
        title,
        description,
        difficulty,
        tags: tags.split(',').map(t => t.trim()).filter(t => t),
        updatedAt: new Date(),
      };

      let challengeId = id;
      if (id) {
        await updateDoc(doc(db, 'challenges', id), challengeData);
      } else {
        const docRef = await addDoc(collection(db, 'challenges'), {
          ...challengeData,
          authorUid: auth.currentUser.uid,
          createdAt: new Date(),
        });
        challengeId = docRef.id;
      }

      // Handle Test Cases (Simplified: delete all and re-add for now, or update if id exists)
      // For a more robust app, we'd do a proper sync.
      if (id) {
        const existingTestCases = await getDocs(collection(db, 'challenges', id, 'testCases'));
        for (const tc of existingTestCases.docs) {
          await deleteDoc(doc(db, 'challenges', id, 'testCases', tc.id));
        }
      }

      for (const tc of testCases) {
        await addDoc(collection(db, 'challenges', challengeId!, 'testCases'), {
          input: tc.input || '',
          expectedOutput: tc.expectedOutput,
          isHidden: tc.isHidden || false,
        });
      }

      toast.success(`Challenge ${id ? 'updated' : 'created'} successfully!`);
      navigate('/admin');
    } catch (error) {
      handleFirestoreError(error, id ? OperationType.UPDATE : OperationType.CREATE, id ? `challenges/${id}` : 'challenges');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-64px)]">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => navigate('/admin')}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors text-gray-500"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl font-extrabold text-gray-900">
          {id ? 'Edit Challenge' : 'Create New Challenge'}
        </h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Info Section */}
        <section className="bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
          <div className="flex items-center gap-2 mb-6 text-indigo-600 font-bold text-lg">
            <Info className="w-5 h-5" />
            Basic Information
          </div>
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Challenge Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                placeholder="e.g. Reverse a String"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Difficulty</label>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value as any)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                >
                  <option value="Easy">Easy</option>
                  <option value="Medium">Medium</option>
                  <option value="Hard">Hard</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Tags (comma separated)</label>
                <input
                  type="text"
                  value={tags}
                  onChange={(e) => setTags(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all"
                  placeholder="e.g. String, Logic, Array"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Description (Markdown Supported)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={8}
                className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all font-mono text-sm"
                placeholder="Describe the problem, constraints, and examples..."
                required
              />
            </div>
          </div>
        </section>

        {/* Test Cases Section */}
        <section className="bg-white rounded-2xl border border-gray-200 p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2 text-indigo-600 font-bold text-lg">
              <Terminal className="w-5 h-5" />
              Test Cases
            </div>
            <button
              type="button"
              onClick={handleAddTestCase}
              className="flex items-center gap-1 text-sm font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-lg transition-all"
            >
              <Plus className="w-4 h-4" />
              Add Test Case
            </button>
          </div>

          <div className="space-y-6">
            {testCases.map((tc, index) => (
              <div key={index} className="p-6 bg-gray-50 rounded-xl border border-gray-200 relative group">
                <button
                  type="button"
                  onClick={() => handleRemoveTestCase(index)}
                  className="absolute top-4 right-4 p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all opacity-0 group-hover:opacity-100"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                    {index + 1}
                  </div>
                  <button
                    type="button"
                    onClick={() => handleTestCaseChange(index, 'isHidden', !tc.isHidden)}
                    className={cn(
                      "flex items-center gap-1 text-xs font-bold px-2 py-1 rounded transition-all",
                      tc.isHidden ? "bg-amber-100 text-amber-700" : "bg-blue-100 text-blue-700"
                    )}
                  >
                    {tc.isHidden ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {tc.isHidden ? 'Hidden' : 'Visible'}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Input</label>
                    <textarea
                      value={tc.input}
                      onChange={(e) => handleTestCaseChange(index, 'input', e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:ring-1 focus:ring-indigo-500 outline-none font-mono text-xs"
                      placeholder="Input for the program..."
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Expected Output</label>
                    <textarea
                      value={tc.expectedOutput}
                      onChange={(e) => handleTestCaseChange(index, 'expectedOutput', e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:ring-1 focus:ring-indigo-500 outline-none font-mono text-xs"
                      placeholder="Expected output..."
                      required
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Action Buttons */}
        <div className="flex justify-end gap-4 pt-4">
          <button
            type="button"
            onClick={() => navigate('/admin')}
            className="px-6 py-3 rounded-xl border border-gray-200 text-gray-600 font-bold hover:bg-gray-50 transition-all"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 bg-indigo-600 text-white px-8 py-3 rounded-xl hover:bg-indigo-700 transition-all shadow-lg font-bold disabled:opacity-50 active:scale-95"
          >
            {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
            {id ? 'Update Challenge' : 'Create Challenge'}
          </button>
        </div>
      </form>
    </div>
  );
}
