import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { db, doc, getDoc, collection, getDocs, auth, addDoc, handleFirestoreError, OperationType } from '../lib/firebase';
import { Challenge, TestCase, Submission, TestCaseResult } from '../types';
import Markdown from 'react-markdown';
import { executeCode } from '../services/geminiService';
import { toast } from 'sonner';
import { Play, Send, CheckCircle, XCircle, Loader2, Code2, Info, Terminal, ChevronDown, ChevronUp, Clock } from 'lucide-react';
import { cn } from '../lib/utils';
import { onAuthStateChanged } from 'firebase/auth';
import { LogIn } from 'lucide-react';

const LANGUAGES = [
  { name: 'Python', value: 'python', defaultCode: 'def solve(input):\n    # Write your code here\n    return input\n\nprint(solve(input()))' },
  { name: 'JavaScript', value: 'javascript', defaultCode: 'function solve(input) {\n    // Write your code here\n    return input;\n}\n\nconsole.log(solve(process.stdin.read().toString()));' },
  { name: 'Java', value: 'java', defaultCode: 'import java.util.Scanner;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        String input = sc.nextLine();\n        // Write your code here\n        System.out.println(input);\n    }\n}' },
  { name: 'C++', value: 'cpp', defaultCode: '#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    string input;\n    getline(cin, input);\n    // Write your code here\n    cout << input << endl;\n    return 0;\n}' },
];

export default function ChallengeDetail() {
  const { id } = useParams<{ id: string }>();
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [loading, setLoading] = useState(true);
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState(LANGUAGES[0]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [results, setResults] = useState<TestCaseResult[]>([]);
  const [activeTab, setActiveTab] = useState<'description' | 'testcases' | 'results'>('description');
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setIsAuthenticated(!!user);
    });
    return unsubscribeAuth;
  }, []);

  useEffect(() => {
    if (!id) return;

    const fetchData = async () => {
      try {
        const challengeDoc = await getDoc(doc(db, 'challenges', id));
        if (challengeDoc.exists()) {
          setChallenge({ id: challengeDoc.id, ...challengeDoc.data() } as Challenge);
          
          if (isAuthenticated) {
            const testCasesSnap = await getDocs(collection(db, 'challenges', id, 'testCases'));
            setTestCases(testCasesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as TestCase)));
          }
          
          setCode(LANGUAGES[0].defaultCode);
        } else {
          toast.error('Challenge not found');
          navigate('/');
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `challenges/${id}`);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, navigate, isAuthenticated]);

  const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const lang = LANGUAGES.find(l => l.value === e.target.value);
    if (lang) {
      setLanguage(lang);
      setCode(lang.defaultCode);
    }
  };

  const handleRunTests = async () => {
    if (!auth.currentUser) {
      toast.error('Please sign in to run tests');
      return;
    }

    setIsExecuting(true);
    setResults([]);
    setActiveTab('results');

    const newResults: TestCaseResult[] = [];
    let allPassed = true;

    try {
      for (const testCase of testCases) {
        const startTime = performance.now();
        const result = await executeCode(code, language.value, testCase.input, testCase.expectedOutput);
        const endTime = performance.now();
        const executionTime = Math.round(endTime - startTime);

        newResults.push({
          testCaseId: testCase.id,
          passed: result.passed,
          actualOutput: result.actualOutput,
          error: result.error,
          executionTime
        });
        if (!result.passed) allPassed = false;
      }

      setResults(newResults);

      // Save submission
      const submissionPath = 'submissions';
      try {
        await addDoc(collection(db, submissionPath), {
          challengeId: id,
          userId: auth.currentUser.uid,
          code,
          language: language.value,
          status: allPassed ? 'Accepted' : 'Wrong Answer',
          results: newResults,
          createdAt: new Date()
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, submissionPath);
      }

      if (allPassed) {
        toast.success('All test cases passed!');
      } else {
        toast.error('Some test cases failed.');
      }
    } catch (error) {
      console.error('Execution error:', error);
      toast.error('An error occurred during execution');
    } finally {
      setIsExecuting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-64px)]">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (!challenge) return null;

  return (
    <div className="h-[calc(100vh-64px)] flex flex-col lg:flex-row overflow-hidden">
      {/* Left Panel: Description & Test Cases */}
      <div className="w-full lg:w-1/2 flex flex-col border-r border-gray-200 bg-white overflow-hidden">
        <div className="flex border-b border-gray-200 bg-gray-50/50">
          <button
            onClick={() => setActiveTab('description')}
            className={cn(
              "px-6 py-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-all",
              activeTab === 'description' ? "border-indigo-600 text-indigo-600 bg-white" : "border-transparent text-gray-500 hover:text-gray-700"
            )}
          >
            <Info className="w-4 h-4" />
            Description
          </button>
          <button
            onClick={() => setActiveTab('testcases')}
            className={cn(
              "px-6 py-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-all",
              activeTab === 'testcases' ? "border-indigo-600 text-indigo-600 bg-white" : "border-transparent text-gray-500 hover:text-gray-700"
            )}
          >
            <Terminal className="w-4 h-4" />
            Test Cases ({testCases.length})
          </button>
          <button
            onClick={() => setActiveTab('results')}
            className={cn(
              "px-6 py-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-all",
              activeTab === 'results' ? "border-indigo-600 text-indigo-600 bg-white" : "border-transparent text-gray-500 hover:text-gray-700"
            )}
          >
            <CheckCircle className="w-4 h-4" />
            Results
          </button>
        </div>

        <div className="flex-grow overflow-y-auto p-8">
          {activeTab === 'description' && (
            <div className="prose prose-indigo max-w-none">
              <h1 className="text-3xl font-bold text-gray-900 mb-2">{challenge.title}</h1>
              <div className="flex gap-2 mb-6">
                <span className={cn(
                  "px-2 py-0.5 rounded text-xs font-bold uppercase",
                  challenge.difficulty === 'Easy' ? "bg-green-100 text-green-700" :
                  challenge.difficulty === 'Medium' ? "bg-yellow-100 text-yellow-700" :
                  "bg-red-100 text-red-700"
                )}>
                  {challenge.difficulty}
                </span>
                {challenge.tags?.map(tag => (
                  <span key={tag} className="px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">
                    {tag}
                  </span>
                ))}
              </div>
              <div className="markdown-body">
                <Markdown>{challenge.description}</Markdown>
              </div>
            </div>
          )}

          {activeTab === 'testcases' && (
            <div className="space-y-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Sample Test Cases</h2>
              {testCases.filter(tc => !tc.isHidden).map((tc, index) => (
                <div key={tc.id} className="bg-gray-50 rounded-lg p-4 border border-gray-200">
                  <div className="text-xs font-bold text-gray-400 uppercase mb-2">Test Case {index + 1}</div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-xs font-semibold text-gray-500 mb-1">Input</div>
                      <pre className="bg-white p-3 rounded border border-gray-200 text-sm font-mono overflow-x-auto">
                        {tc.input || '(empty)'}
                      </pre>
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-gray-500 mb-1">Expected Output</div>
                      <pre className="bg-white p-3 rounded border border-gray-200 text-sm font-mono overflow-x-auto">
                        {tc.expectedOutput}
                      </pre>
                    </div>
                  </div>
                </div>
              ))}
              {testCases.filter(tc => tc.isHidden).length > 0 && (
                <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-lg text-indigo-700 text-sm flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  There are {testCases.filter(tc => tc.isHidden).length} hidden test cases that will be used for final evaluation.
                </div>
              )}
            </div>
          )}

          {activeTab === 'results' && (
            <div className="space-y-4">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Execution Results</h2>
              {isExecuting ? (
                <div className="flex flex-col items-center justify-center py-20 text-gray-500">
                  <Loader2 className="w-10 h-10 animate-spin mb-4 text-indigo-600" />
                  <p className="font-medium animate-pulse">Executing code against test cases...</p>
                  <p className="text-xs mt-2">This may take a few seconds as we simulate the environment.</p>
                </div>
              ) : results.length > 0 ? (
                <div className="space-y-4">
                  {results.map((result, index) => {
                    const testCase = testCases.find(tc => tc.id === result.testCaseId);
                    return (
                      <div key={result.testCaseId} className={cn(
                        "border rounded-lg overflow-hidden transition-all",
                        result.passed ? "border-green-200 bg-green-50/30" : "border-red-200 bg-red-50/30"
                      )}>
                        <div className="px-4 py-3 flex items-center justify-between bg-white/50 border-b border-inherit">
                          <div className="flex items-center gap-2">
                            {result.passed ? (
                              <CheckCircle className="w-5 h-5 text-green-600" />
                            ) : (
                              <XCircle className="w-5 h-5 text-red-600" />
                            )}
                            <span className="font-bold text-sm">
                              Test Case {index + 1} {testCase?.isHidden ? '(Hidden)' : ''}
                            </span>
                            {result.executionTime !== undefined && (
                              <span className="text-[10px] text-gray-400 font-mono flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {result.executionTime}ms
                              </span>
                            )}
                          </div>
                          <span className={cn(
                            "text-xs font-bold uppercase px-2 py-0.5 rounded",
                            result.passed ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                          )}>
                            {result.passed ? 'Passed' : 'Failed'}
                          </span>
                        </div>
                        
                        {!testCase?.isHidden && (
                          <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <div className="text-xs font-semibold text-gray-500 mb-1">Expected</div>
                              <pre className="bg-white p-2 rounded border border-gray-100 font-mono text-xs">
                                {testCase?.expectedOutput}
                              </pre>
                            </div>
                            <div>
                              <div className="text-xs font-semibold text-gray-500 mb-1">Actual</div>
                              <pre className={cn(
                                "bg-white p-2 rounded border font-mono text-xs",
                                result.passed ? "border-green-100" : "border-red-100 text-red-600"
                              )}>
                                {result.actualOutput || (result.error ? 'Error' : '(empty)')}
                              </pre>
                            </div>
                            {result.error && (
                              <div className="col-span-full mt-2 p-3 bg-red-900 text-red-100 rounded font-mono text-xs overflow-x-auto">
                                <div className="font-bold mb-1">Runtime Error:</div>
                                {result.error}
                              </div>
                            )}
                          </div>
                        )}
                        {testCase?.isHidden && !result.passed && (
                          <div className="p-4 text-sm text-red-600 font-medium italic">
                            Hidden test case failed. Check your logic for edge cases.
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-20 text-center text-gray-400">
                  <Play className="w-12 h-12 mx-auto mb-4 opacity-20" />
                  <p>Run your code to see results here.</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Right Panel: Code Editor */}
      <div className="w-full lg:w-1/2 flex flex-col bg-[#1e1e1e] text-white">
        {!isAuthenticated ? (
          <div className="flex-grow flex items-center justify-center p-8 bg-gray-50 dark:bg-gray-950 transition-colors duration-300">
            <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-12 shadow-sm max-w-md mx-auto text-center">
              <LogIn className="w-12 h-12 text-indigo-600 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Ready to Solve?</h2>
              <p className="text-gray-600 dark:text-gray-400 mb-8">Please sign in to access the code editor and submit your solution.</p>
              <button
                onClick={() => window.location.reload()}
                className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg active:scale-95"
              >
                Sign In to Continue
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between px-4 py-2 bg-[#252526] border-b border-[#333]">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-indigo-400 font-semibold text-sm">
                  <Code2 className="w-4 h-4" />
                  Editor
                </div>
                <select
                  value={language.value}
                  onChange={handleLanguageChange}
                  className="bg-[#3c3c3c] text-white text-xs font-medium px-2 py-1 rounded border border-[#555] focus:outline-none focus:ring-1 focus:ring-indigo-500"
                >
                  {LANGUAGES.map(lang => (
                    <option key={lang.value} value={lang.value}>{lang.name}</option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleRunTests}
                  disabled={isExecuting}
                  className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white px-4 py-1.5 rounded-md text-sm font-bold transition-all shadow-lg active:scale-95"
                >
                  {isExecuting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                  Run Tests
                </button>
              </div>
            </div>

            <div className="flex-grow relative font-mono text-sm">
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                spellCheck={false}
                className="absolute inset-0 w-full h-full bg-transparent p-6 focus:outline-none resize-none leading-relaxed text-gray-300 selection:bg-indigo-500/30"
                placeholder="Write your code here..."
              />
              {/* Line numbers (visual only) */}
              <div className="absolute left-0 top-0 bottom-0 w-12 bg-[#1e1e1e] border-r border-[#333] flex flex-col items-center pt-6 text-[#858585] select-none pointer-events-none">
                {code.split('\n').map((_, i) => (
                  <div key={i} className="h-[1.625rem] leading-relaxed">{i + 1}</div>
                ))}
              </div>
              <div className="absolute left-12 right-0 top-0 bottom-0 pointer-events-none" />
            </div>

            <div className="bg-[#252526] px-4 py-2 border-t border-[#333] flex items-center justify-between text-[10px] text-gray-500 uppercase tracking-widest font-bold">
              <div className="flex gap-4">
                <span>UTF-8</span>
                <span>Spaces: 4</span>
              </div>
              <div>
                {language.name}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
