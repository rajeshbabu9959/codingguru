import React, { useEffect, useState } from 'react';
import { db, collection, query, where, orderBy, onSnapshot, auth, handleFirestoreError, OperationType, getDocs } from '../lib/firebase';
import { Submission, Challenge } from '../types';
import { onAuthStateChanged } from 'firebase/auth';
import { CheckCircle, XCircle, Clock, Code, ChevronRight, BarChart3, Award, Zap } from 'lucide-react';
import { cn, formatDate } from '../lib/utils';
import { Link } from 'react-router-dom';

export default function Profile() {
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [challenges, setChallenges] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(auth.currentUser);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) setLoading(false);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (!user) return;

    const path = 'submissions';
    const q = query(
      collection(db, path),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const subs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Submission));
      setSubmissions(subs);

      // Fetch challenge titles
      const challengeIds = Array.from(new Set(subs.map(s => s.challengeId)));
      const challengeMap: Record<string, string> = {};
      
      for (const id of challengeIds) {
        try {
          const cDoc = await getDocs(query(collection(db, 'challenges'))); // Simplified for now, or fetch individually
          // Actually, let's just fetch all challenges once for the map
          snapshot.docs.forEach(doc => {
             // This is inefficient but works for small sets
          });
        } catch (e) {}
      }
      
      // Better way: fetch all challenges to map IDs to titles
      const challengesSnap = await getDocs(collection(db, 'challenges'));
      challengesSnap.forEach(doc => {
        challengeMap[doc.id] = (doc.data() as Challenge).title;
      });
      setChallenges(challengeMap);
      
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });

    return unsubscribe;
  }, [user]);

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-12 flex justify-center">
        <Clock className="w-10 h-10 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-900">Please sign in to view your report</h2>
      </div>
    );
  }

  const stats = {
    total: submissions.length,
    accepted: submissions.filter(s => s.status === 'Accepted').length,
    languages: Array.from(new Set(submissions.map(s => s.language))).length,
    uniqueChallenges: Array.from(new Set(submissions.map(s => s.challengeId))).length
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-extrabold text-gray-900 flex items-center gap-3">
          <BarChart3 className="w-8 h-8 text-indigo-600" />
          Practice Report
        </h1>
        <p className="text-gray-500 mt-1">Track your progress and review your coding history.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 text-gray-500 text-sm font-bold uppercase mb-2">
            <Zap className="w-4 h-4 text-yellow-500" />
            Total Submissions
          </div>
          <div className="text-3xl font-black text-gray-900">{stats.total}</div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 text-gray-500 text-sm font-bold uppercase mb-2">
            <Award className="w-4 h-4 text-green-500" />
            Accepted
          </div>
          <div className="text-3xl font-black text-gray-900">{stats.accepted}</div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 text-gray-500 text-sm font-bold uppercase mb-2">
            <Code className="w-4 h-4 text-indigo-500" />
            Languages
          </div>
          <div className="text-3xl font-black text-gray-900">{stats.languages}</div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
          <div className="flex items-center gap-3 text-gray-500 text-sm font-bold uppercase mb-2">
            <CheckCircle className="w-4 h-4 text-blue-500" />
            Challenges Solved
          </div>
          <div className="text-3xl font-black text-gray-900">{stats.uniqueChallenges}</div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
          <h2 className="font-bold text-gray-900">Recent Activity</h2>
        </div>
        <div className="divide-y divide-gray-100">
          {submissions.length > 0 ? (
            submissions.map((sub) => (
              <div key={sub.id} className="p-6 hover:bg-gray-50 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                    sub.status === 'Accepted' ? "bg-green-100 text-green-600" : "bg-red-100 text-red-600"
                  )}>
                    {sub.status === 'Accepted' ? <CheckCircle className="w-6 h-6" /> : <XCircle className="w-6 h-6" />}
                  </div>
                  <div>
                    <Link to={`/challenge/${sub.challengeId}`} className="font-bold text-gray-900 hover:text-indigo-600 transition-colors">
                      {challenges[sub.challengeId] || 'Unknown Challenge'}
                    </Link>
                    <div className="flex items-center gap-3 mt-1 text-xs text-gray-500 font-medium">
                      <span className="uppercase tracking-wider">{sub.language}</span>
                      <span>•</span>
                      <span>{formatDate(sub.createdAt)}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                    sub.status === 'Accepted' ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                  )}>
                    {sub.status}
                  </div>
                  <Link to={`/challenge/${sub.challengeId}`} className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all">
                    <ChevronRight className="w-5 h-5" />
                  </Link>
                </div>
              </div>
            ))
          ) : (
            <div className="py-20 text-center text-gray-400">
              <Code className="w-12 h-12 mx-auto mb-4 opacity-20" />
              <p>No submissions yet. Start practicing!</p>
              <Link to="/" className="text-indigo-600 hover:underline text-sm mt-2 inline-block">
                Browse Challenges
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
