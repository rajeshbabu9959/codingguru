import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { db, collection, onSnapshot, query, orderBy, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';
import { Challenge } from '../types';
import { BookOpen, ChevronRight, Code, Trophy, LogIn } from 'lucide-react';
import { cn } from '../lib/utils';

export default function ChallengeList() {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => {
      setIsAuthenticated(!!user);
    });
    return unsubscribeAuth;
  }, []);

  useEffect(() => {
    const path = 'challenges';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Challenge));
      setChallenges(data);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });
    return unsubscribe;
  }, []);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-48 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-10 text-center">
        <h1 className="text-4xl font-extrabold text-gray-900 tracking-tight sm:text-5xl mb-4">
          Master Your Coding Skills
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Solve real-world challenges, test your logic, and level up your programming expertise across multiple languages.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {challenges.length > 0 ? (
          challenges.map((challenge) => (
            <Link
              key={challenge.id}
              to={`/challenge/${challenge.id}`}
              className="group bg-white rounded-xl border border-gray-200 p-6 hover:border-indigo-500 hover:shadow-lg transition-all duration-300 flex flex-col"
            >
              <div className="flex justify-between items-start mb-4">
                <div className={cn(
                  "px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider",
                  challenge.difficulty === 'Easy' ? "bg-green-100 text-green-700" :
                  challenge.difficulty === 'Medium' ? "bg-yellow-100 text-yellow-700" :
                  "bg-red-100 text-red-700"
                )}>
                  {challenge.difficulty}
                </div>
                <Trophy className="w-5 h-5 text-gray-300 group-hover:text-yellow-500 transition-colors" />
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-indigo-600 transition-colors">
                {challenge.title}
              </h3>
              
              <p className="text-gray-600 text-sm line-clamp-3 mb-6 flex-grow">
                {challenge.description}
              </p>

              <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                <div className="flex gap-2">
                  {challenge.tags?.slice(0, 2).map((tag) => (
                    <span key={tag} className="text-[10px] font-semibold bg-gray-100 text-gray-500 px-2 py-0.5 rounded uppercase">
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex items-center text-indigo-600 font-semibold text-sm">
                  Solve <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </Link>
          ))
        ) : (
          <div className="col-span-full py-20 text-center bg-white rounded-2xl border-2 border-dashed border-gray-200">
            <Code className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-xl font-medium text-gray-600">No challenges found</h3>
            <p className="text-gray-400 mt-2">Check back later or start by adding a new challenge as an admin.</p>
          </div>
        )}
      </div>
    </div>
  );
}
