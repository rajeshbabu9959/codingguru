import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { db, collection, onSnapshot, query, orderBy, deleteDoc, doc, auth, getDoc, handleFirestoreError, OperationType } from '../lib/firebase';
import { Challenge, User } from '../types';
import { Plus, Edit, Trash2, ShieldCheck, Loader2, AlertCircle, ChevronRight, BookOpen, Send } from 'lucide-react';
import { toast } from 'sonner';
import { cn, formatDate } from '../lib/utils';
import { onAuthStateChanged } from 'firebase/auth';
import { updateDoc } from 'firebase/firestore';

export default function AdminDashboard() {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const path = `users/${user.uid}`;
        try {
          const userDoc = await getDoc(doc(db, 'users', user.uid));
          const userData = userDoc.data() as User;
          if (userData?.role === 'admin') {
            setIsAdmin(true);
          } else {
            toast.error('Access denied. Admin only.');
            navigate('/');
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, path);
        }
      } else {
        toast.error('Please sign in as an admin');
        navigate('/');
      }
    });

    return unsubscribeAuth;
  }, [navigate]);

  useEffect(() => {
    if (!isAdmin) return;

    const path = 'challenges';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    const unsubscribeChallenges = onSnapshot(q, (snapshot) => {
      setChallenges(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Challenge)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    });

    return unsubscribeChallenges;
  }, [isAdmin]);

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this challenge? This will also delete all associated test cases.')) {
      const path = `challenges/${id}`;
      try {
        await deleteDoc(doc(db, 'challenges', id));
        toast.success('Challenge deleted successfully');
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, path);
      }
    }
  };

  const handleStatusUpdate = async (id: string, status: 'Pending Review') => {
    const path = `challenges/${id}`;
    try {
      await updateDoc(doc(db, 'challenges', id), { status });
      toast.success(`Challenge status updated to ${status}`);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-64px)]">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (!isAdmin) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-10">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900 flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-indigo-600" />
            Admin Dashboard
          </h1>
          <p className="text-gray-500 mt-1">Manage coding challenges and test cases for the platform.</p>
        </div>
        <Link
          to="/admin/new"
          className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-xl hover:bg-indigo-700 transition-all shadow-md font-bold active:scale-95"
        >
          <Plus className="w-5 h-5" />
          Create New Challenge
        </Link>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Challenge</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Difficulty</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider">Created At</th>
                <th className="px-6 py-4 text-xs font-bold text-gray-500 uppercase tracking-wider text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {challenges.length > 0 ? (
                challenges.map((challenge) => (
                  <tr key={challenge.id} className="hover:bg-gray-50/50 transition-colors group">
                    <td className="px-6 py-5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                          <BookOpen className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="font-bold text-gray-900">{challenge.title}</div>
                          <div className="text-xs text-gray-500 flex gap-2 mt-1">
                            {challenge.tags?.map(tag => (
                              <span key={tag}>#{tag}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-5">
                      <span className={cn(
                        "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                        challenge.difficulty === 'Easy' ? "bg-green-100 text-green-700" :
                        challenge.difficulty === 'Medium' ? "bg-yellow-100 text-yellow-700" :
                        "bg-red-100 text-red-700"
                      )}>
                        {challenge.difficulty}
                      </span>
                    </td>
                    <td className="px-6 py-5">
                      <span className={cn(
                        "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                        challenge.status === 'Published' ? "bg-blue-100 text-blue-700" :
                        challenge.status === 'Pending Review' ? "bg-orange-100 text-orange-700" :
                        "bg-gray-100 text-gray-700"
                      )}>
                        {challenge.status || 'Draft'}
                      </span>
                    </td>
                    <td className="px-6 py-5 text-sm text-gray-500 font-medium">
                      {formatDate(challenge.createdAt)}
                    </td>
                    <td className="px-6 py-5 text-right">
                      <div className="flex justify-end gap-2">
                        {challenge.status !== 'Pending Review' && challenge.status !== 'Published' && (
                          <button
                            onClick={() => handleStatusUpdate(challenge.id, 'Pending Review')}
                            className="p-2 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-all"
                            title="Submit for Review"
                          >
                            <Send className="w-5 h-5" />
                          </button>
                        )}
                        <Link
                          to={`/admin/edit/${challenge.id}`}
                          className="p-2 text-gray-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                          title="Edit Challenge"
                        >
                          <Edit className="w-5 h-5" />
                        </Link>
                        <button
                          onClick={() => handleDelete(challenge.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                          title="Delete Challenge"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                        <Link
                          to={`/challenge/${challenge.id}`}
                          className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-all"
                          title="View Challenge"
                        >
                          <ChevronRight className="w-5 h-5" />
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-20 text-center text-gray-400">
                    <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p className="font-medium">No challenges created yet.</p>
                    <Link to="/admin/new" className="text-indigo-600 hover:underline text-sm mt-2 inline-block">
                      Create your first challenge
                    </Link>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
